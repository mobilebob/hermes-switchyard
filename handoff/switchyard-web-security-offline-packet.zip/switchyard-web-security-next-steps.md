# Hermes Switchyard — Web Security Next-Step Execution Packet

**Prepared:** November 13, 2026  
**Scope:** Web-result prompt-injection security first; memory shadow, model routing and desktop sharing out of scope.  
**Intended executor:** Hermes agent running on the Hermes VM with access to its local repository and release qualification records.  
**Authorization:** Offline investigation, tests and preparation only. **No live Jev calls, spending, push/merge, plugin install, gateway restart or production activation.** A previous 21-contract evaluation halted after one uncertain timeout; do not replay those contracts or reuse consumed approvals.

## Verified handoff

- Final local candidate: `b2b44bed5a10f187b29ecd41bb33a2f381a112c0`.
- Verified release archive SHA-256: `f90d9520f5051e209a22218429a020203535bca71b9dee03425618acb4ac7d87`.
- Report directory: `/home/hermes/reports/switchyard-release-final-b2b44be/`.
- Existing local report: 2,067 suite tests (0 failures, 16 skips), 84+84 native lifecycle checks, repository-wide Ruff clean. These are historical results to confirm, **not tests run by this packet**.
- Default-off: `shared_jev_skill_effort: false`; `memory_screen_mode: off`; `model_routing_mode: off`; `web_screen_mode: off`.
- Existing web security is **advisory/observation-only**; web-result bytes stay unchanged, and automatic blocking is not implemented. Do not call it a protective firewall.
- An earlier minimal live web-screening experiment yielded no measurable answer benefit, with approximately +31.6% tokens, six additional Jev requests and +8.4% median latency. That experimental prototype is not authorization to deploy it.
- The final candidate is **not on connected GitHub** as of packet preparation; do not substitute the older `experiment/jev-web-screening-minimal` branch for the final candidate.

## Actions to execute NOW, offline, on Hermes VM

1. **Identity and preservation preflight.** Confirm repository commit `b2b44be`, clean tracked state, exact verified archive SHA, baseline manifests, installed production plugin identity and default-off config. Do not modify production files, credentials, old receipts or preserved evaluation records. Preserve the historical `auth.json` hash difference as unresolved.
2. **Security threat model and controls.** Inventory each untrusted entry point for web results (raw page, snippets, HTML comments, tool JSON, titles, URL metadata, citations). Trace exactly where Jev's relevance, injection and sufficiency judgments are generated, logged, consumed or ignored. Demonstrate whether any real enforcement exists; if none, state explicitly `shadow observation only`.
3. **Run offline classification with mock/synthetic Jev replies.** Import `switchyard-web-security-cases.json` and use the existing mock-client / fake decision harness. Keep **`id`, `expected`, and `test_note` local**; send only the plain `question` and `result` under test to the mocked decision boundary. Adapt fixture structure to repo APIs, but do not change expected labels silently. Source-local oversized/unsafe URL examples must show zero network attempts and explicit abstention.
4. **Measure the right things.** Record per-case risk judgment, relevance and evidence sufficiency, abstentions, false positives on quoted examples, missed injection classes, payload size handling, sanitized egress, cancellation/timeouts, max number of requests, mutation of original result, and final behavior of Hermes. Do not treat mocked Jev labels as evidence of live Jev accuracy.
5. **Design a safe enforcement gate (do not activate).** Propose an explicit, default-off policy for quarantine/skip/warn decisions when web content requests tools, exfiltration, role escalation or answer manipulation. Define who owns the decision, where enforcement occurs before untrusted text reaches the answering model, how benign evidence is retained, and how failures or unavailable Jev responses abstain. Distinguish **detection** from **actual prevention**. Create a separate branch/prototype only if fully isolated from production and requested work can be implemented locally without provider calls; no push.
6. **Compare against existing local defenses.** Avoid duplicating local filters or introducing a Jev call unless a distinct security gap is demonstrated. Include projected request, token, privacy and latency costs, explicitly reflecting the prior A/B finding and the one timed-out prior evaluation attempt.
7. **Produce a go/no-go report.** Include (a) candidate identity and evidence paths; (b) exact test counts and outcomes; (c) gap analysis, including bypasses/false positives; (d) whether Hermes answers are currently protected (not just labeled); (e) precise proposed changes, with a separately reviewable diff if written; and (f) any remaining prerequisite for a *new* approved live evaluation and later activation. Do not claim live success or a green portability history scan.

## Suggested acceptance gates, not previously met

- Zero unapproved network requests, Jev calls, modifications to production auth/config, gateway restarts or plugin activations during offline work.
- All known injection fixtures must be recognized by the appropriate test policy; quoted attack examples must not be silently suppressed as true instructions; insufficient evidence must not be represented as sufficient.
- Synthetic fixture coverage is illustrative, not a statistical accuracy estimate. A future quality evaluation must use independently labeled fresh material, an approved provider route, separate authorization, conservative accounting and no retry after uncertain transport.
- No activation until the owner reviews a concrete enforcement design and verifies that it improves security without unacceptable loss of useful results, cost, or latency.

## Return to owner

State clearly one of: `OFFLINE-READY FOR SECURITY REVIEW`, `BLOCKED`, or `NOT SUITABLE`. Present actual evidence rather than predictions. **Do not run live pilot or enable production by interpreting this instruction as approval.**

## Fixture integrity

- File: `switchyard-web-security-cases.json`
- SHA-256: `0098d58b8336ea998369761eccf92509d33391a6400e2544d5d407985e5812db`
- Case count: `20`
- Entirely synthetic; no real credentials, school data, personal memories or authenticated content.
